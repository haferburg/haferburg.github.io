local project_name = "rayMarching"
local build_dir = "B:/" .. project_name

dofile("D:/coding/src/glsdk_0.5.0/links.lua")

solution (project_name)
  configurations {"Debug", "Release"}
  location (build_dir)
project (project_name)
  kind "ConsoleApp"
  language "c++"
  location (build_dir)
  files {"*.cpp", "*.hpp", "*.glsl"}
  UseLibs {"glload", "freeglut", "glm"}
  configuration "windows"
    defines "WIN32"
    links {"glu32", "opengl32", "gdi32", "winmm", "user32"}
  configuration "linux"
    links {"GL"}
  configuration "Debug"
    targetsuffix "D"
    defines "_DEBUG"
    flags "Symbols"
  configuration "Release"
    defines "NDEBUG"
    flags {"OptimizeSpeed", "NoFramePointer", "ExtraWarnings", "NoEditAndContinue"};

