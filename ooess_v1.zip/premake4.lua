dofile("D:/coding/src/glsdk_0.5.0/links.lua")

solution "fastRayMarching"
  configurations {"Debug", "Release"}
  location ("B:/fastRayMarching")
project "fastRayMarching"
  kind "ConsoleApp"
  language "c++"
  location ("B:/fastRayMarching")
  files {"*.cpp", "*.hpp", "*.glsl"}
  UseLibs {"glload", "freeglut", "glm"}
  configuration "windows"
    defines "WIN32"
    links {"glu32", "opengl32", "gdi32", "winmm", "user32"}
  configuration "linux"
    links {"GL"}
  configuration "Debug"
    targetsuffix "D"
    defines "_DEBUG"
    flags "Symbols"
  configuration "Release"
    defines "NDEBUG"
    flags {"OptimizeSpeed", "NoFramePointer", "ExtraWarnings", "NoEditAndContinue"};

