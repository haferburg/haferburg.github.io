#include <glload/gl_4_3_comp.h>
#include <glload/gl_load.hpp>

#include <glm/glm.hpp>
#include <glm/ext.hpp>

#include <GL/freeglut.h>

#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>
#include <list>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <sys/types.h>
#include <sys/stat.h>
#include <iomanip>

using namespace glm;

//const int glut_profile = GLUT_CORE_PROFILE;
const int glut_profile = GLUT_COMPATIBILITY_PROFILE;

const bool showFps = true && glut_profile != GLUT_CORE_PROFILE;

const bool zNearCanIntersectVolume = false;

enum VolumeType {BEETLE, BUNNY, BALLS};

// Coordinate systems:
// volume: uvw coordinates in ivec3(0) to volumeDim
// grid: ivec3(0) to gridDim
// voltex: normalized texture coordinates in vec3(0) to vec3(1)
// viewport
// eye (NDC)
// world
// object

ivec3 volumeDim, gridDim(0);
// aka scaleVolumeToGrid
ivec3 voxelsPerCell;
int maxVolumeDim, maxGridDim;
const float cubeSize = 30.f;
vec3 scaleWorldToGrid;
// aka scaleGridToVoltex
vec3 maxGridPos;
vec3 scaleWorldToVoltex;

int screenWidth = 0, screenHeight = 0;
mat4 eyeToViewport;

float isoValue = 0.9375f;
float minIsoValue = 0, maxIsoValue = 1;

GLfloat backgroundGray = 0.3f;

// Camera
vec3 ptEyeToWorld = vec3(0, 0, 50);
vec3 ptWorldToGrid;
float fov = 45.f;

// Mouse handling
bool dragLeft = false, dragRight = false;
int dragStartX, dragStartY;
ivec2 mousePos;
vec3 eyeStart = vec3(ptEyeToWorld);
float rotX = 0, rotY = 0, rotXStart, rotYStart;
float fovStart;
bool envelopeIsDirty = true;

// FPS
std::string fpsString;

void initializeParameters(VolumeType& volumeType)
{
  // Frame rates for 1920x1200, no DEBUG, stepSize = 1
  //fov = 29.8f; rotY = -214.f; rotX = 6.f; ptEyeToWorld = rotateY(rotateX(eyeStart, rotX), rotY);

  volumeType = BEETLE; gridDim = ivec3(1);                   //  24 FPS
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  17; //  84 FPS (49x49x50)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  20; //  94 FPS (42x42x42)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  26; //  99 FPS (32x32x33)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  32; // 105 FPS (26x26x26)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  42; // 111 FPS (20x20x19)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  52; // 113 FPS (16x16x17) *
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  64; // 113 FPS (13x13x13)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  80; // 110 FPS (11x11x11)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  84; // 108 FPS (10x10x10)
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim = 104; // 100 FPS (8x8x9)

  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  52; // 113 FPS (16x16x17) *
  //volumeType = BALLS; volumeDim = ivec3(832, 832, 494); gridDim = ivec3(0); maxGridDim = 52;
  volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  17; //  84 FPS (49x49x50)

  //fov = 34.f; rotY = -169.f; rotX = -9.f; ptEyeToWorld = rotateY(rotateX(eyeStart, rotX), rotY);
  //volumeType = BUNNY; gridDim = ivec3(0); maxGridDim = 16;
  //volumeType = BUNNY; gridDim = ivec3(0); maxGridDim = 512/8;
  //volumeType = BUNNY; gridDim = ivec3(0); maxGridDim = 512/2;

  //volumeType = BEETLE; gridDim = ivec3(0); maxGridDim =  52; // 113 FPS (16x16x17) *
  //volumeType = BALLS; volumeDim = ivec3(832, 832, 494); gridDim = ivec3(0); maxGridDim = 104;
  volumeType = BALLS; volumeDim = ivec3(256, 230, 150); gridDim = ivec3(0); maxGridDim = 16;
}

class ShaderProgram
{
public:
  ShaderProgram()
  : isLinked(false)
  {
    program = glCreateProgram();
  };

  ~ShaderProgram()
  {
    glDeleteProgram(program);
  };

  void loadShader(const std::string &strShaderFile)
  {
    std::string type = strShaderFile.substr(strShaderFile.length() - 9, 4);
    GLenum shaderType;
    if (type == "geom")
      shaderType = GL_GEOMETRY_SHADER;
    else if (type == "comp")
      shaderType = GL_COMPUTE_SHADER;
    else if (type == "frag")
      shaderType = GL_FRAGMENT_SHADER;
    else if (type == "vert")
      shaderType = GL_VERTEX_SHADER;
    else if (type == "tess")
      shaderType = GL_TESS_EVALUATION_SHADER;
    else if (type == "ctrl")
      shaderType = GL_TESS_CONTROL_SHADER;
    else
      throw std::runtime_error("bad filename");

    loadShader(shaderType, strShaderFile);
  }

  void loadShader(GLenum eShaderType, const std::string &strShaderFile)
  {
    std::ifstream in(strShaderFile);
    std::stringstream buffer;
    buffer << in.rdbuf();

    addShader(eShaderType, buffer.str());
  }

  void addShader(GLenum eShaderType, const std::string &shaderCode)
  {
    //std::cout << shaderCode << "\n\n";
    GLuint shaderId = glCreateShader(eShaderType);
    const char *strFileData = shaderCode.c_str();
    glShaderSource(shaderId, 1, &strFileData, NULL);

    glCompileShader(shaderId);

    GLint status;
    glGetShaderiv(shaderId, GL_COMPILE_STATUS, &status);
    if (status == GL_FALSE)
    {
      GLint infoLogLength;
      glGetShaderiv(shaderId, GL_INFO_LOG_LENGTH, &infoLogLength);

      GLchar *strInfoLog = new GLchar[infoLogLength + 1];
      glGetShaderInfoLog(shaderId, infoLogLength, NULL, strInfoLog);

      const char *strShaderType = NULL;
      switch(eShaderType)
      {
      case GL_VERTEX_SHADER: strShaderType = "vertex"; break;
      case GL_FRAGMENT_SHADER: strShaderType = "fragment"; break;
      case GL_GEOMETRY_SHADER: strShaderType = "geometry"; break;
      case GL_TESS_CONTROL_SHADER: strShaderType = "tess control"; break;
      case GL_TESS_EVALUATION_SHADER: strShaderType = "tess eval"; break;
      case GL_COMPUTE_SHADER: strShaderType = "compute"; break;
      }

      fprintf(stderr, "Compile failure in %s shader:\n%s\n", strShaderType, strInfoLog);
      delete[] strInfoLog;
    }

    shaderList.push_back(shaderId);
  };

  void link(GLsizei countCaptured = 0, const char *captured[] = nullptr)
  {
    isLinked = true;

    for(size_t iLoop = 0; iLoop < shaderList.size(); iLoop++)
      glAttachShader(program, shaderList[iLoop]);

    if (countCaptured)
      glTransformFeedbackVaryings(program, countCaptured, captured, GL_SEPARATE_ATTRIBS);

    glLinkProgram(program);

    GLint status;
    glGetProgramiv (program, GL_LINK_STATUS, &status);
    if (status == GL_FALSE)
    {
      GLint infoLogLength;
      glGetProgramiv(program, GL_INFO_LOG_LENGTH, &infoLogLength);

      GLchar *strInfoLog = new GLchar[infoLogLength + 1];
      glGetProgramInfoLog(program, infoLogLength, NULL, strInfoLog);
      fprintf(stderr, "Linker failure: %s\n", strInfoLog);
      delete[] strInfoLog;
    }
    else
      std::cout << "Shader program " << program << " linked successfully" << std::endl;

    for(size_t iLoop = 0; iLoop < shaderList.size(); iLoop++)
      glDetachShader(program, shaderList[iLoop]);

    std::for_each(shaderList.begin(), shaderList.end(), glDeleteShader);
    shaderList.clear();
  }

  void use()
  {
    if (!isLinked)
      std::cout << "Program " << program << " wasn't linked" << std::endl;
    glUseProgram(program);
    usedProgram = program;
  }

  GLint uniform(const std::string& uniformName)
  {
    if (usedProgram != program)
    {
      std::cout << "WARNING: Program not bound!" << std::endl;
    }

    auto it = uniMap.find(uniformName);
    if (it == uniMap.end())
    {
      GLint result = glGetUniformLocation(program, uniformName.c_str());
      //std::cout << "Found uniform " << uniformName << " in program " << program << " at " << result << std::endl;
      uniMap[uniformName] = result;
      return result;
    }

    return it->second;
  }

  void uniform(const std::string& uniformName, GLint value) {glUniform1i(uniform(uniformName), value);}
  void uniform(const std::string& uniformName, GLuint value) {glUniform1ui(uniform(uniformName), unsigned int(value));}
  void uniform(const std::string& uniformName, GLfloat value){glUniform1f(uniform(uniformName), value);}
  void uniform(const std::string& uniformName, bool value) {uniform(uniformName, GLuint(value));}

  void uniform(const std::string& uniformName, const ivec2& value) {glUniform2iv(uniform(uniformName), 1, value_ptr(value));}
  void uniform(const std::string& uniformName, const ivec3& value) {glUniform3iv(uniform(uniformName), 1, value_ptr(value));}
  void uniform(const std::string& uniformName, const vec3& value) {glUniform3fv(uniform(uniformName), 1, value_ptr(value));}
  void uniform(const std::string& uniformName, const vec4& value) {glUniform4fv(uniform(uniformName), 1, value_ptr(value));}

  void uniform(const std::string& uniformName, const mat4& value, GLboolean transpose = GL_FALSE)
  {
    glUniformMatrix4fv(uniform(uniformName), 1, transpose, value_ptr(value));
  }

  // Disable implicit casts.
  template <typename T> void uniform(const std::string&, T) = delete;

  void unUse()
  {
    usedProgram = 0;
    glUseProgram(0);
  }

private:
  static GLuint usedProgram;
  GLuint program;
  bool isLinked;
  std::vector<GLuint> shaderList;
  std::map<std::string, GLint> uniMap;
};
GLuint ShaderProgram::usedProgram = 0;


std::map<std::string, time_t> fileTime;
const size_t numShaders = 10;
std::string shaderFileName[numShaders] = {
  "envelope.vert.glsl", "envelope.geom.glsl", "iso_surface.frag.glsl",
  "simple.vert.glsl", "depth.frag.glsl",
  "draw_line.vert.glsl", "create_line.geom.glsl", "draw_line.frag.glsl",
  "wireframe.geom.glsl", "wireframe.frag.glsl",
};
ShaderProgram *createEnvelopeProgram = nullptr, *minMaxDepthProgram = nullptr, *isoSurfaceProgram = nullptr;
ShaderProgram *lineProgram = nullptr, *solidWireframeProgram = nullptr;
ShaderProgram *testProgram = nullptr;

// GL objects
GLuint volumeTexId, gridTexId;
GLuint pointsVboId;
GLuint pointsArrayId;
GLuint envelopeVboId, envelopeNumTris;
GLuint envelopeArrayId;
GLuint atomicsBufId, numAtomics = 7;
GLuint offscreenDepthMapFboId = 0, offscreenDepthMapTexId = 0;
GLuint cubeVaoId, cubeVerticesVboId, cubeIndicesVboId;
int numCubeIndices;

// Option toggles
bool showCubes = false, showCubeBacksides = false, countNumTextureAccess = false, showCost = false;
bool drawWireFrame = true;
bool useBoundingBox = false;

GLuint generate3DTexture(GLenum texture, GLint minMagFilter)
{
  GLuint result;
  glActiveTexture(texture);
  glGenTextures(1, &result);
  glBindTexture(GL_TEXTURE_3D, result);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, minMagFilter);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, minMagFilter);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
  glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_BORDER);
  glTexParameterfv(GL_TEXTURE_3D, GL_TEXTURE_BORDER_COLOR, value_ptr(vec4(0)));
  return result;
}

void loadBunny()
{
  std::cout << "Loading Stanford bunny" << std::endl;

  volumeDim = ivec3(512, 512, 360); // = (64, 64, 45) * 8
  isoValue = 0.1f;

  unsigned char* voxels = new unsigned char[volumeDim.x * volumeDim.y * volumeDim.z];
  {
    unsigned char* p = voxels;
    unsigned short* sliceData = new unsigned short[volumeDim.x * volumeDim.y];
    int sliceSize = volumeDim.x * volumeDim.y;
    for (int slice = 0; slice < volumeDim.z; slice++)
    {
      std::stringstream ss;
      ss << "C:/data/bunny/" << (slice + 1);
      std::ifstream f(ss.str(), std::ios::in | std::ios::binary);
      f.read((char*)sliceData, sliceSize * sizeof(unsigned short));

      unsigned char* q = (unsigned char*)sliceData;
      for (int i = 0; i < sliceSize; i++, q+=2, p++)
        *p = unsigned char(((q[0] << 8) + q[1]) >> 4); // Mac byte ordering, discard 4 of the 12 significant bits
    }
    delete sliceData;
  }

  std::cout << "Uploading to GPU" << std::endl;

  volumeTexId = generate3DTexture(GL_TEXTURE0, GL_LINEAR);
  glTexImage3D(GL_TEXTURE_3D, 0, GL_R8, volumeDim.x, volumeDim.y, volumeDim.z, 0,
    GL_RED, GL_UNSIGNED_BYTE, voxels);
  delete [] voxels;

  std::cout << "Stripping bunny" << std::endl;

  ShaderProgram computeBunnyShader;
  computeBunnyShader.loadShader("strip_bunny.comp.glsl");
  computeBunnyShader.link();
  computeBunnyShader.use();
  computeBunnyShader.uniform("volume", 0);
  glBindImageTexture(0, volumeTexId, 0, GL_TRUE, 0, GL_READ_WRITE, GL_R8);
  glDispatchCompute(volumeDim.x, volumeDim.y, volumeDim.z);
  computeBunnyShader.unUse();
  glMemoryBarrier(GL_ALL_BARRIER_BITS);

  std::cout << "Done." << std::endl;
}

void loadBeetle()
{
  std::cout << "Loading stag beetle" << std::endl;

  std::ifstream f("C:/data/stagbeetle832x832x494.dat", std::ios::in | std::ios::binary);

  unsigned short vuSize[3];
  f.read((char*)vuSize, 3 * sizeof(unsigned short));
  volumeDim = ivec3(vuSize[0], vuSize[1], vuSize[2]);

  int numVoxels = volumeDim.x * volumeDim.y * volumeDim.z;
  unsigned short *filedata = new unsigned short[numVoxels];
  f.read((char*)filedata, numVoxels * sizeof(unsigned short));

  std::cout << "Scaling data" << std::endl;
  unsigned char *voxels = new unsigned char[numVoxels];
  for (int i = 0; i < numVoxels; i++)
    voxels[i] = unsigned char(filedata[i] >> 4); // 12 significant bits, discard 4
  delete [] filedata;

  std::cout << "Uploading to GPU" << std::endl;

  volumeTexId = generate3DTexture(GL_TEXTURE0, GL_LINEAR);
  glTexImage3D(GL_TEXTURE_3D, 0, GL_R8, volumeDim.x, volumeDim.y, volumeDim.z, 0,
    GL_RED, GL_UNSIGNED_BYTE, voxels);

  std::cout << "Deleting data" << std::endl;
  delete [] voxels;

  isoValue = 0.1625f;

  std::cout << "Done." << std::endl;
}

void computeBalls()
{
  std::cout << "Initializing volume" << std::endl;

  volumeTexId = generate3DTexture(GL_TEXTURE0, GL_LINEAR);
  glTexStorage3D(GL_TEXTURE_3D, 1, GL_R8, volumeDim.x, volumeDim.y, volumeDim.z);

  ShaderProgram computeVolumeShader;
  computeVolumeShader.loadShader("compute_balls.comp.glsl");
  computeVolumeShader.link();

  glBindImageTexture(0, volumeTexId, 0, GL_TRUE, 0, GL_WRITE_ONLY, GL_R8);

  computeVolumeShader.use();
  computeVolumeShader.uniform("volume", 0);

  glDispatchCompute(volumeDim.x, volumeDim.y, volumeDim.z);

  computeVolumeShader.unUse();
  glMemoryBarrier(GL_ALL_BARRIER_BITS);

  std::cout << "Done." << std::endl;
}

template <typename T> std::ostream& operator <<(std::ostream& os, glm::detail::tvec3<T> v)
{return os << v.x << " " << v.y << " " << v.z;}

void initializeDimensions()
{
  std::cout << "volumeDim = " << volumeDim << std::endl;

  // Grid dimensions
  if (gridDim == ivec3(0))
    gridDim = max(ivec3(1), volumeDim / (max(volumeDim.x, volumeDim.y, volumeDim.z) / maxGridDim));
  voxelsPerCell = ivec3(ceil(vec3(volumeDim) / vec3(gridDim)));
  std::cout << "gridDim = " << gridDim << std::endl;
  std::cout << "voxelsPerCell = " << voxelsPerCell << std::endl;

  // Given a grid, we want to scale the max dimension to cubeSize (WCS).
  // E.g. volumeDim = (17,13), gridDim = (4,4), voxelsPerCell = (17/4, 13/4) = (5,4), cubeSize = 30.
  maxVolumeDim = max(volumeDim.x, volumeDim.y, volumeDim.z); // 17
  std::cout << "maxVolumeDim " << maxVolumeDim << std::endl;
  vec3 scaleWorldToVolume = vec3(cubeSize / maxVolumeDim); // 30/17 = 1.77
  scaleWorldToVoltex = scaleWorldToVolume * vec3(volumeDim); // (30, 22.9)
  std::cout << "scaleWorldToVoltex " << scaleWorldToVoltex << std::endl;
  ptWorldToGrid = -scaleWorldToVoltex / 2.0f;
  scaleWorldToGrid = scaleWorldToVolume * vec3(voxelsPerCell); // 1.77*(5,4) = (8.82, 7.05)
  std::cout << "scaleWorldToGrid " << scaleWorldToGrid << std::endl;

  maxGridPos = vec3(volumeDim) / vec3(voxelsPerCell);
}


void computeGridTexture()
{
  gridTexId = generate3DTexture(GL_TEXTURE1, GL_NEAREST);
  if (gridDim == ivec3(1))
  {
    size_t size = gridDim.x * gridDim.y * gridDim.z;
    unsigned short* data = new unsigned short[size];
    for (size_t i = 0; i < size; i++)
      data[i] = 0xFFFF;
    glTexImage3D(GL_TEXTURE_3D, 0, GL_R8, gridDim.x, gridDim.y, gridDim.z, 0, GL_RED, GL_UNSIGNED_BYTE, data);
    delete [] data;
    return;
  }

  glTexStorage3D(GL_TEXTURE_3D, 1, GL_R8, gridDim.x, gridDim.y, gridDim.z);

  glBindImageTexture(0, volumeTexId, 0, GL_TRUE, 0, GL_READ_ONLY, GL_R8);
  glBindImageTexture(1, gridTexId, 0, GL_TRUE, 0, GL_WRITE_ONLY, GL_R8);

  ShaderProgram computeGridProgram;
  computeGridProgram.loadShader("grid.comp.glsl");
  computeGridProgram.link();

  computeGridProgram.use();
  computeGridProgram.uniform("volume", 0);
  computeGridProgram.uniform("grid", 1);
  computeGridProgram.uniform("voxelsPerCell", voxelsPerCell);
  computeGridProgram.uniform("volumeDim", volumeDim);

  glDispatchCompute(gridDim.x, gridDim.y, gridDim.z);

  computeGridProgram.unUse();
}

void initializeInputPoints()
{
  glGenBuffers(1, &pointsVboId);
  float positions[] = {1.0f};

  glBindBuffer(GL_ARRAY_BUFFER, pointsVboId);
  glBufferData(GL_ARRAY_BUFFER, sizeof(positions), positions, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glGenVertexArrays(1, &pointsArrayId);
}

GLsizeiptr maxNumTris;
void initializeOutputBuffer()
{
  GLsizeiptr numGridVoxels = gridDim.x * gridDim.y * gridDim.z;
  // For each pair of grid voxel neighbors, we generate 2 triangles if the voxel is above and
  // the neighbor is below the iso threshold. In the worst case, we generate a full cube (12 tris)
  // for every other voxel.
  //GLsizeiptr maxNumTris = (numGridVoxels + 1) * 6;

  // Instead of the worst case, consider a n*n*n grid where each voxel is active, so we have
  // 6*n*n quads. Now if the grid were subdivided by a gap slice in the middle, it adds about
  // 2*n*n quads. We'll allow 5 of these gaps.
  GLsizeiptr maxGridDim = max(gridDim.x, gridDim.y, gridDim.z);
  maxNumTris = 2 * maxGridDim * maxGridDim * (6 + 5 * 2);

  GLsizeiptr maxNumVertices = maxNumTris * 3;
  GLsizeiptr maxNumBytes = maxNumVertices * sizeof(int);
  std::cout << "maxNumTris = " << maxNumTris << ", maxNumBytes = " << maxNumBytes << std::endl;

  glGenBuffers(1, &envelopeVboId);
  glBindBuffer(GL_ARRAY_BUFFER, envelopeVboId);
  glBufferData(GL_ARRAY_BUFFER, maxNumBytes, nullptr, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);

  glGenVertexArrays(1, &envelopeArrayId);
}


void createCube()
{
  const int vertexPositions[] = {
    0, 0, 0,
    1, 0, 0,
    0, 1, 0,
    1, 1, 0,
    0, 0, 1,
    1, 0, 1,
    0, 1, 1,
    1, 1, 1,
  };
#define QUAD(a,b,c,d) a,c,b, d,c,a
  int indices[] = {
    QUAD(4, 6, 7, 5),
    QUAD(6, 2, 3, 7),
    QUAD(3, 2, 0, 1),
    QUAD(1, 0, 4, 5),
    QUAD(0, 2, 6, 4),
    QUAD(7, 3, 1, 5),
  };
#undef QUAD
  numCubeIndices = sizeof(indices) / sizeof(int);
  for (int l = 0; l < numCubeIndices; l++)
    indices[l] = vertexPositions[3*indices[l]] + 1024 * (vertexPositions[3*indices[l]+1] + 1024 * vertexPositions[3*indices[l]+2]);

  glGenBuffers(1, &cubeIndicesVboId);
  glBindBuffer(GL_ARRAY_BUFFER, cubeIndicesVboId);
  glBufferData(GL_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

  glGenVertexArrays(1, &cubeVaoId);
}

void initializeAtomicCounters()
{
  glGenBuffers(1, &atomicsBufId);
  glBindBuffer(GL_ATOMIC_COUNTER_BUFFER, atomicsBufId);
  glBufferData(GL_ATOMIC_COUNTER_BUFFER, numAtomics * sizeof(GLuint), nullptr, GL_DYNAMIC_COPY);
  glBindBuffer(GL_ATOMIC_COUNTER_BUFFER, 0);
}

void loadShaders()
{
  {
    if (createEnvelopeProgram)
      delete createEnvelopeProgram;

    createEnvelopeProgram = new ShaderProgram();
    createEnvelopeProgram->loadShader("envelope.vert.glsl");
    createEnvelopeProgram->loadShader("envelope.geom.glsl");

    const char *captured[] = {"packedGridToPos"};
    createEnvelopeProgram->link(1, captured);

    createEnvelopeProgram->use();
    createEnvelopeProgram->uniform("gridDim", gridDim);
    createEnvelopeProgram->uniform("maxGridPos", maxGridPos);
    createEnvelopeProgram->uniform("iso", isoValue);
    createEnvelopeProgram->uniform("gridVolume", 1);
    createEnvelopeProgram->unUse();
  }

  {
    if (isoSurfaceProgram)
      delete isoSurfaceProgram;

    isoSurfaceProgram = new ShaderProgram();
    isoSurfaceProgram->loadShader("indexed.vert.glsl");
    isoSurfaceProgram->loadShader("iso_surface.frag.glsl");
    isoSurfaceProgram->link();

    isoSurfaceProgram->use();
    isoSurfaceProgram->uniform("volume", 0);
    isoSurfaceProgram->uniform("maxGridPos", maxGridPos);
    isoSurfaceProgram->uniform("volumeDim", volumeDim);
    isoSurfaceProgram->uniform("maxVolumeDim", maxVolumeDim);
    isoSurfaceProgram->uniform("depthTex", 2);
    isoSurfaceProgram->uniform("iso", isoValue);
    isoSurfaceProgram->uniform("showCubes", showCubes);
    isoSurfaceProgram->uniform("showCubeBacksides", showCubeBacksides);
    isoSurfaceProgram->uniform("showCost", showCost);
    isoSurfaceProgram->uniform("countNumTextureAccess", countNumTextureAccess);
    isoSurfaceProgram->uniform("zNearCanIntersectVolume", zNearCanIntersectVolume);
    isoSurfaceProgram->unUse();
  }

  {
    if (minMaxDepthProgram)
      delete minMaxDepthProgram;

    minMaxDepthProgram = new ShaderProgram();
    minMaxDepthProgram->loadShader("indexed.vert.glsl");
    minMaxDepthProgram->loadShader("depth.frag.glsl");
    minMaxDepthProgram->link();

    minMaxDepthProgram->use();
    minMaxDepthProgram->uniform("maxGridPos", maxGridPos);
    minMaxDepthProgram->uniform("zNearCanIntersectVolume", zNearCanIntersectVolume);
    minMaxDepthProgram->unUse();
  }

  {
    if (testProgram)
      delete testProgram;

    testProgram = new ShaderProgram();
    testProgram->loadShader("indexed.vert.glsl");
    testProgram->loadShader("test.frag.glsl");
    testProgram->link();

    testProgram->use();
    testProgram->uniform("maxGridPos", maxGridPos);
    testProgram->unUse();
  }

  {
    if (lineProgram)
      delete lineProgram;

    lineProgram = new ShaderProgram();
    lineProgram->loadShader("draw_line.vert.glsl");
    lineProgram->loadShader("create_line.geom.glsl");
    lineProgram->loadShader("draw_line.frag.glsl");
    lineProgram->link();

    lineProgram->use();
    lineProgram->uniform("quadHack", true);
    lineProgram->unUse();
  }

  {
    if (solidWireframeProgram)
      delete solidWireframeProgram;

    solidWireframeProgram = new ShaderProgram();
    solidWireframeProgram->loadShader("draw_line.vert.glsl");
    solidWireframeProgram->loadShader("wireframe.geom.glsl");
    solidWireframeProgram->loadShader("wireframe.frag.glsl");
    solidWireframeProgram->link();
  }
}

void checkShaderFiles(int)
{
  glutTimerFunc(2000, checkShaderFiles, 0);

  bool anyChange = false, isoShaderChanged = false;
  for (int i = 0; i < numShaders; i++)
  {
    std::string shaderFileName = ::shaderFileName[i];

    struct stat st;
    int ierr = stat(shaderFileName.c_str(), &st);
    if (ierr != 0)
      std::cout << "Error getting file stats of " << shaderFileName << std::endl;

    time_t currentFileTime = st.st_mtime;
    time_t lastFileTime = fileTime[shaderFileName];
    if (currentFileTime != lastFileTime)
    {
      fileTime[shaderFileName] = currentFileTime;
      anyChange = true;
      if (shaderFileName.substr(0, 8) == "envelope")
        envelopeIsDirty = true;
    }
  }

  if (anyChange)
  {
    loadShaders();
    glutPostRedisplay();
  }
}

void initializeOffscreenDepthMap()
{
  if (!offscreenDepthMapFboId)
    glGenFramebuffers(1, &offscreenDepthMapFboId);

  if (!screenWidth || !screenHeight)
    return;

  if (offscreenDepthMapTexId)
  {
    glDeleteTextures(1, &offscreenDepthMapTexId);
  }

  glActiveTexture(GL_TEXTURE2);
  glGenTextures(1, &offscreenDepthMapTexId);
  glBindTexture(GL_TEXTURE_2D, offscreenDepthMapTexId);
  GLenum internalformat = zNearCanIntersectVolume ? GL_RGB32F : GL_RG32F;
  glTexStorage2D(GL_TEXTURE_2D, 1, internalformat, screenWidth, screenHeight);

  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, offscreenDepthMapFboId);
  glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
    offscreenDepthMapTexId, 0);

  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
  {
    std::cout << "!!! Offscreen depth buffer incomplete" << std::endl;
  }

  glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void reshape(int w, int h)
{
  screenWidth = w;
  screenHeight = h;
  vec4 vp(0, 0, screenWidth, screenHeight);
  //vec4 eyePos;
  //eyePos.xy = 2.0 * (gl_FragCoord.xy - viewport.xy) / viewport.zw - 1;
  //eyePos.z = (2.0 * depthScreen - (f + n)) / fn;
  //eyePos.w = 1.0;
  //vec4 gridPos = gridToEye * eyePos;
  eyeToViewport = glm::translate(-2.0f * vec3(vp.x / vp.z, vp.y / vp.w, 0.f) - 1.f)
    * glm::scale(vec3(2.0 / vp.z, 2.0 / vp.w, 2.0));
  glViewport(0, 0, w, h);

  // Initialize offscreen depth buffer.
  initializeOffscreenDepthMap();
}

void mouseMove(int x, int y)
{
  mousePos.x = x;
  mousePos.y = screenHeight - y;
  glutPostRedisplay();
}

void mouseButton(int button, int state, int x, int y)
{
  if (button == GLUT_LEFT_BUTTON)
  {
    dragLeft = !dragRight && state == GLUT_DOWN;
    if (dragLeft)
    {
      dragStartX = x;
      dragStartY = y;
      rotXStart = rotX;
      rotYStart = rotY;
    }
  }
  else if (button == GLUT_RIGHT_BUTTON)
  {
    dragRight = !dragLeft && state == GLUT_DOWN;
    if (dragRight)
    {
      dragStartX = x;
      dragStartY = y;
      fovStart = fov;
    }
  }
}


void mouseDrag(int x, int y)
{
  if (dragLeft)
  {
    float deltaX = (float)(x - dragStartX);
    float deltaY = (float)(y - dragStartY);

    float degreesPerScreenWidth = 180.f;
    rotY = rotYStart - deltaX * degreesPerScreenWidth / screenWidth;
    rotX = clamp(rotXStart - deltaY * degreesPerScreenWidth / screenHeight, -89.f, 89.f);
    ptEyeToWorld = rotateY(rotateX(eyeStart, rotX), rotY);
    glutPostRedisplay();
  }
  else if (dragRight)
  {
    float deltaX = (float)(x - dragStartX);
    float deltaY = (float)(y - dragStartY);
    float delta = deltaX + deltaY;

    fov = clamp(fovStart + delta / 10.f, 2.f, 90.f);
    glutPostRedisplay();
  }
}

void keyboardFunc(unsigned char c, int, int)
{
  if (c == 27 /* Esc */)
    glutLeaveMainLoop();
  else if (c == 'a')
  {
    countNumTextureAccess = !countNumTextureAccess;
    isoSurfaceProgram->use();
    isoSurfaceProgram->uniform("countNumTextureAccess", countNumTextureAccess);
    isoSurfaceProgram->unUse();
    void idleFunc();
    glutIdleFunc(countNumTextureAccess ? nullptr : idleFunc);
    glutPostRedisplay();
  }
  else if (c == 'w')
  {
    drawWireFrame = !drawWireFrame;
    glutPostRedisplay();
  }
  else if (c == 'g')
  {
    useBoundingBox = !useBoundingBox;
    glutPostRedisplay();
  }
  else if (c == 'c' || c == 'q' || c == 'b')
  {
    showCost = c == 'q' ? !showCost : false;
    showCubes = c == 'c' ? !showCubes : false;
    showCubeBacksides = c == 'b' ? !showCubeBacksides : false;

    isoSurfaceProgram->use();
    isoSurfaceProgram->uniform("showCubeBacksides", showCubeBacksides);
    isoSurfaceProgram->uniform("showCubes", showCubes);
    isoSurfaceProgram->uniform("showCost", showCost);
    isoSurfaceProgram->unUse();
    glutPostRedisplay();
  }
}

void idleFunc()
{
  static int frameCounter = 0;
  static int previousTime = glutGet(GLUT_ELAPSED_TIME);

  frameCounter++;
  int currentTime = glutGet(GLUT_ELAPSED_TIME);

  if (currentTime - previousTime > 1000)
  {
    // Compute averages over the last 1 and 10 seconds.
    static std::list<int> frameNumbers;
    static std::list<double> frameTimes;
    if (frameNumbers.size() == 0)
    {
      frameNumbers.push_front(0);
      frameTimes.push_front(previousTime);
    }

    frameNumbers.push_front(frameCounter);
    frameTimes.push_front(currentTime);
    if (frameNumbers.size() > 11)
    {
      frameNumbers.pop_back();
      frameTimes.pop_back();
    }

    auto formatFPS = [&](double frame2, double time2) -> std::string
    {
      double numFrames = frameNumbers.front() - frame2;
      double dt = frameTimes.front() - time2;
      double msPerFrame = dt / numFrames;
      double fps = 1000.0 / msPerFrame;
      std::stringstream ss;
      ss << fps << " FPS, " << msPerFrame << " ms";
      return ss.str();
    };

    std::string fps1s = formatFPS((*++frameNumbers.begin()), (*++frameTimes.begin()));
    std::string fps10s = formatFPS(frameNumbers.back(), frameTimes.back());

    previousTime = currentTime;
    std::stringstream ss;
    ss << fps1s << " (" << fps10s << /*" over "<< frameNumbers.size() - 1 << "s"*/")";
    fpsString = ss.str();
  }
}

void mouseWheel(int button, int dir, int x, int y)
{
  float delta = 0.0125f;
  if (dir > 0)
    isoValue += delta;
  else
    isoValue -= delta;
  isoValue = clamp(isoValue, minIsoValue, maxIsoValue);
  std::cout << isoValue << std::endl;
  createEnvelopeProgram->use();
  createEnvelopeProgram->uniform("iso", isoValue);
  isoSurfaceProgram->use();
  isoSurfaceProgram->uniform("iso", isoValue);
  isoSurfaceProgram->unUse();

  envelopeIsDirty = true;
  glutPostRedisplay();
}

void computeEnvelope()
{
  createEnvelopeProgram->use();
  GLuint qid;
  glGenQueries(1, &qid);
  glBeginQuery(GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN, qid);

  glBindVertexArray(pointsArrayId);
  glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER, 0, envelopeVboId);
  glEnable(GL_RASTERIZER_DISCARD);
  glBeginTransformFeedback(GL_TRIANGLES);
  GLsizei instanceCount = gridDim.x * gridDim.y * gridDim.z;
  glDrawArraysInstanced(GL_POINTS, 0, 1, instanceCount);
  glEndTransformFeedback();
  glDisable(GL_RASTERIZER_DISCARD);

  glEndQuery(GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN);
  glGetQueryObjectuiv(qid, GL_QUERY_RESULT, &envelopeNumTris);

  int numBytes = envelopeNumTris * 3 * sizeof(int);
  std::cout << envelopeNumTris << " triangles generated, " << numBytes << " byte" << std::endl;

  glBindVertexArray(0);
  createEnvelopeProgram->unUse();

  envelopeIsDirty = false;
}

void resetAtomicCounters()
{
  glBindBuffer(GL_ATOMIC_COUNTER_BUFFER, atomicsBufId);
  GLuint* ptr = (GLuint*)glMapBufferRange(GL_ATOMIC_COUNTER_BUFFER, 0,
    numAtomics * sizeof(GLuint), GL_MAP_WRITE_BIT);
  for (size_t i = 0; i < numAtomics; i++)
    ptr[i] = 0;
  glUnmapBuffer(GL_ATOMIC_COUNTER_BUFFER);
  glBindBufferBase(GL_ATOMIC_COUNTER_BUFFER, 0, atomicsBufId);
}

void readAtomicCounters(std::string& stringToDraw1, std::string& stringToDraw2)
{
  glBindBuffer(GL_ATOMIC_COUNTER_BUFFER, atomicsBufId);
  GLuint* ptr = (GLuint*)glMapBufferRange(GL_ATOMIC_COUNTER_BUFFER, 0,
    numAtomics * sizeof(GLuint), GL_MAP_READ_BIT);
  long long ptrLong[4];
  for (int i = 0; i < 4; i++)
    ptrLong[i] = ptr[i];

  int numTextureAccessMousePos = ptr[4];
  int numInvocationsMousePos = ptr[5];
  int numIterationsMousePos = ptr[6];

  long long numTextureAccess = ptrLong[0] + 2 * ptrLong[1] + 8 * ptrLong[2] + 32 * ptrLong[3];
  glUnmapBuffer(GL_ATOMIC_COUNTER_BUFFER);
  glBindBuffer(GL_ATOMIC_COUNTER_BUFFER, 0);

  if (numTextureAccessMousePos)
  {
    std::stringstream ss;
    ss << numTextureAccessMousePos << " tex @ "
      << "(" << mousePos.x << "," << mousePos.y << "), "
      << numInvocationsMousePos << " invocations, "
      << numIterationsMousePos << " iterations";
    stringToDraw2 = ss.str();
  }

  if (countNumTextureAccess && numTextureAccess > 0)
  {
    std::stringstream ss;
    ss.imbue(std::locale(""));
    ss << std::fixed << numTextureAccess << " texture accesses" << std::endl;
    stringToDraw1 = ss.str();
  }
  else
  {
    stringToDraw1.clear();
  }

}

void drawEnvelope()
{
  glBindVertexArray(envelopeArrayId);
  glBindBuffer(GL_ARRAY_BUFFER, envelopeVboId);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 4, GL_UNSIGNED_INT_2_10_10_10_REV, GL_FALSE, 0, nullptr);

  glDrawArrays(GL_TRIANGLES, 0, 3 * envelopeNumTris);
}

void drawCube()
{
  glBindVertexArray(cubeVaoId);
  glBindBuffer(GL_ARRAY_BUFFER, cubeIndicesVboId);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 4, GL_UNSIGNED_INT_2_10_10_10_REV, GL_FALSE, 0, nullptr);

  glDrawArrays(GL_TRIANGLES, 0, 3 * numCubeIndices);

  glDisableVertexAttribArray(0);
}

void drawString(const std::string &stringToDraw, float& yPos)
{
  if (stringToDraw.empty())
    return;

  glColor3f(0,0,0);
  glWindowPos3f(12.f, screenHeight - yPos - 2, 0.5f);
  glutBitmapString(GLUT_BITMAP_HELVETICA_18, (const unsigned char*)stringToDraw.c_str());
  glColor3f(1,1,1);
  glWindowPos3f(10.f, screenHeight - yPos, 0.f);
  glutBitmapString(GLUT_BITMAP_HELVETICA_18, (const unsigned char*)stringToDraw.c_str());

  yPos += 20.f;
}

void display(void)
{
  if (!screenWidth)
    return;

  if (envelopeIsDirty)
    computeEnvelope();

  float distToEye = length(ptEyeToWorld);
  float zNear = 0.1f, zFar = distToEye + 2.0f * cubeSize;
  if (zNearCanIntersectVolume)
    zNear = distToEye - 0.3f * cubeSize; // test intersection with near plane
  // Transform camera to eye space, aka projection matrix.
  mat4 eyeToCamera = perspective(fov, float(screenWidth) / float(screenHeight), zNear, zFar);
  // Transform world to camera space, aka view matrix.
  mat4 cameraToWorld = lookAt(ptEyeToWorld, vec3(), vec3(0, 1, 0)) * rotate(90.f, vec3(1,0,0));

  mat4 gridToVoltex = scale(maxGridPos);
  mat4 worldToGrid = translate(ptWorldToGrid) * scale(scaleWorldToGrid);
  mat4 cameraToGrid = cameraToWorld * worldToGrid;
  mat4 eyeToGrid = eyeToCamera * cameraToGrid;
  mat4 cameraToVoltex = cameraToGrid * gridToVoltex;
  mat4 viewportToGrid = inverse(eyeToViewport) * eyeToGrid;
  mat4 viewportToVoltex = viewportToGrid * gridToVoltex;
  mat4 voltexToViewport = inverse(viewportToVoltex);

  // First pass: Render min/max depth as RG into offscreen FBO.
  glBindFramebuffer(GL_DRAW_FRAMEBUFFER, offscreenDepthMapFboId);
  glDrawBuffer(GL_COLOR_ATTACHMENT0);
  glClearColor(1.f, 1.f, 1.f, 0);
  glClear(GL_COLOR_BUFFER_BIT);

  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);
  glEnable(GL_BLEND);
  glBlendEquation(GL_MIN);

  minMaxDepthProgram->use();

  bool useGrid = GLsizeiptr(envelopeNumTris) < maxNumTris && !useBoundingBox;
  if (useGrid)
  {
    minMaxDepthProgram->uniform("eyeToObject", eyeToGrid);
    drawEnvelope();
  }
  else
  {
    minMaxDepthProgram->uniform("eyeToObject", eyeToGrid * scale(maxGridPos));
    drawCube();
  }

  minMaxDepthProgram->unUse();
  std::string stringToDraw1, stringToDraw2;

  resetAtomicCounters();

  // Second pass: Render front faces into screen framebuffer.
  glBindFramebuffer(GL_FRAMEBUFFER, 0);
  glClearColor(backgroundGray, backgroundGray, backgroundGray, 1);
  glClearDepth(1);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LESS);
  glEnable(GL_CULL_FACE);
  glCullFace(zNearCanIntersectVolume ? GL_FRONT : GL_BACK);
  glDisable(GL_BLEND);

  isoSurfaceProgram->use();
  isoSurfaceProgram->uniform("viewportToVoltex", viewportToVoltex);
  isoSurfaceProgram->uniform("voltexToViewport", voltexToViewport);
  isoSurfaceProgram->uniform("cameraToVoltex", cameraToVoltex);
  isoSurfaceProgram->uniform("mousePos", mousePos);

  if (useGrid)
  {
    isoSurfaceProgram->uniform("eyeToObject", eyeToGrid);
    glDrawArrays(GL_TRIANGLES, 0, 3 * envelopeNumTris);
    glDisableVertexAttribArray(0);
  }
  else
  {
    isoSurfaceProgram->uniform("eyeToObject", eyeToGrid * scale(maxGridPos));
    drawCube();
  }

  isoSurfaceProgram->unUse();

  readAtomicCounters(stringToDraw1, stringToDraw2);
  glBindBuffer(GL_ATOMIC_COUNTER_BUFFER, 0);

  if (drawWireFrame)
  {
    glDepthMask(GL_FALSE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBlendEquation(GL_FUNC_ADD);
    glEnable(GL_DEPTH_TEST);
    if (showCubeBacksides)
    {
      glDepthFunc(GL_GEQUAL);
      glEnable(GL_CULL_FACE);
      glCullFace(GL_FRONT);
    }
    else
    {
      glDepthFunc(GL_LEQUAL);
      glDisable(GL_CULL_FACE);
    }

    if (useGrid)
    {
      //ShaderProgram* shader = testProgram;
      ShaderProgram* shader = lineProgram;
      //ShaderProgram* shader = solidWireframeProgram;
      shader->use();
      shader->uniform("eyeToObject", eyeToGrid);
      shader->uniform("viewportToObject", viewportToGrid);
      shader->uniform("eyeToViewport", eyeToViewport);
      shader->uniform("maxGridPos", maxGridPos);

      drawEnvelope();
      glDisableVertexAttribArray(0);
      shader->unUse();
    }

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBlendEquation(GL_FUNC_ADD);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_CULL_FACE);

    lineProgram->use();
    lineProgram->uniform("eyeToObject", eyeToGrid * scale(maxGridPos));
    lineProgram->uniform("viewportToObject", viewportToGrid * scale(maxGridPos));
    lineProgram->uniform("eyeToViewport", eyeToViewport);
    lineProgram->uniform("maxGridPos", vec3(1));
    drawCube();
    lineProgram->unUse();

    glDepthMask(GL_TRUE);
  }

  if (::glut_profile != GLUT_CORE_PROFILE)
  {
    glDisable(GL_BLEND);
    glDisable(GL_DEPTH_TEST);
    float yPos = 20.f;
    drawString(!countNumTextureAccess ? fpsString : stringToDraw1, yPos);
    drawString(stringToDraw2, yPos);
  }

  glFlush();
  glutSwapBuffers();

  if (!countNumTextureAccess && showFps)
    glutPostRedisplay();
}

void APIENTRY DebugFunc(GLenum source, GLenum type, GLuint id, GLenum severity, GLsizei length,
         const GLchar* message, GLvoid*)
{
  std::string srcName;
  switch(source)
  {
  case GL_DEBUG_SOURCE_API_ARB: srcName = "API"; break;
  case GL_DEBUG_SOURCE_WINDOW_SYSTEM_ARB: srcName = "Window System"; break;
  case GL_DEBUG_SOURCE_SHADER_COMPILER_ARB: srcName = "Shader Compiler"; break;
  case GL_DEBUG_SOURCE_THIRD_PARTY_ARB: srcName = "Third Party"; break;
  case GL_DEBUG_SOURCE_APPLICATION_ARB: srcName = "Application"; break;
  case GL_DEBUG_SOURCE_OTHER_ARB: srcName = "Other"; break;
  }

  std::string errorType;
  switch(type)
  {
  case GL_DEBUG_TYPE_ERROR_ARB: errorType = "Error"; break;
  case GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR_ARB: errorType = "Deprecated Functionality"; break;
  case GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR_ARB: errorType = "Undefined Behavior"; break;
  case GL_DEBUG_TYPE_PORTABILITY_ARB: errorType = "Portability"; break;
  case GL_DEBUG_TYPE_PERFORMANCE_ARB: errorType = "Performance"; break;
  case GL_DEBUG_TYPE_OTHER_ARB: errorType = "Other"; break;
  }

  std::string typeSeverity;
  switch(severity)
  {
  case GL_DEBUG_SEVERITY_HIGH_ARB: typeSeverity = "High"; break;
  case GL_DEBUG_SEVERITY_MEDIUM_ARB: typeSeverity = "Medium"; break;
  case GL_DEBUG_SEVERITY_LOW_ARB: typeSeverity = "Low"; break;
  }

  printf("%s from %s,\t%s priority\nMessage: %s\n",
    errorType.c_str(), srcName.c_str(), typeSeverity.c_str(), message);
}


int main(int argc, char **argv)
{
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DEPTH | GLUT_SINGLE | GLUT_RGBA);
  //glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA); // caps FPS at 60
  glutInitContextVersion(4, 3);
  glutInitContextProfile(glut_profile);

  glutInitContextFlags(GLUT_DEBUG);

  //glutInitWindowSize(1920/2, 1200/2);
  //glutInitWindowSize(800, 600);
  glutInitWindowSize(600, 450);
  glutInitWindowPosition(800, 200);

  glutCreateWindow("fastRayMarching");

  glload::LoadFunctions();
  glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_CONTINUE_EXECUTION);

  if(glext_ARB_debug_output)
  {
    glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS_ARB);
    glDebugMessageCallbackARB(DebugFunc, nullptr);
  }

  VolumeType volumeType = BALLS;
  initializeParameters(volumeType);

  // Generate the 3D texture.
  if (volumeType == BUNNY)
    loadBunny();
  else if (volumeType == BEETLE)
    loadBeetle();
  else if (volumeType == BALLS)
    computeBalls();

  initializeDimensions();

  computeGridTexture();

  // Create VBO for geometry shader input.
  initializeInputPoints();

  // Initialize output VBO.
  initializeOutputBuffer();

  createCube();

  initializeAtomicCounters();

  // Load shaders.
  checkShaderFiles(1);

  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboardFunc);
  glutPassiveMotionFunc(mouseMove);
  glutMouseFunc(mouseButton);
  glutMotionFunc(mouseDrag);
  glutMouseWheelFunc(mouseWheel);
  if (showFps)
    glutIdleFunc(idleFunc);

  glutMainLoop();

  return 0;
}


